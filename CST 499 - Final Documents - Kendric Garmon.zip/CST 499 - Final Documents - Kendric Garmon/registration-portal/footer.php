<footer class="footer mt-auto py-3">
    <span class="text-muted">&copy; <?php echo date("Y");?> Online Learning Platform</span>
</footer>